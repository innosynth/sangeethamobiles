# sangeethamobiles


pm2 command to run

pm2 start "uvicorn backend.main:app --host 0.0.0.0 --port 8080" --name sangeetha
